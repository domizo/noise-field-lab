import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import '@fontsource-variable/dm-sans';
import '@fontsource/ibm-plex-mono/400.css';
import './styles.css';
createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>);
